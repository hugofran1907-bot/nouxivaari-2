// NOU XIVARRI - lógica compartida del sitio (menú de navegación, mapa y llamadas)
document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Menú de navegación (funciona en todas las páginas) ---------- */
  var toggle = document.getElementById('menuToggle');
  var panel = document.getElementById('mainNavPanel');

  if (toggle && panel) {
    toggle.setAttribute('aria-expanded', 'false');

    toggle.addEventListener('click', function (e) {
      e.stopPropagation();
      var isHidden = panel.classList.toggle('hidden');
      toggle.setAttribute('aria-expanded', String(!isHidden));
    });

    document.addEventListener('click', function (e) {
      if (!panel.contains(e.target) && !toggle.contains(e.target)) {
        panel.classList.add('hidden');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        panel.classList.add('hidden');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Resalta la página actual dentro del menú
  var current = document.body.getAttribute('data-page');
  document.querySelectorAll('.nav-link').forEach(function (link) {
    if (link.getAttribute('data-page') === current) {
      link.classList.add('bg-surface-container-high', 'text-tertiary', 'font-semibold');
    }
  });

  /* ---------- Aviso flotante (para acciones solo-móvil) ---------- */
  function showToast(message) {
    var existing = document.getElementById('xivarriToast');
    if (existing) existing.remove();

    var toast = document.createElement('div');
    toast.id = 'xivarriToast';
    toast.textContent = message;
    toast.className = 'fixed bottom-6 left-1/2 -translate-x-1/2 bg-on-background text-background text-sm font-medium px-5 py-3 rounded-full shadow-lg z-[100] text-center max-w-[90vw]';
    document.body.appendChild(toast);
    setTimeout(function () {
      toast.remove();
    }, 3500);
  }

  /* ---------- Llamar / Pedir a domicilio: solo en móvil ---------- */
  function isMobile() {
    return window.matchMedia('(max-width: 767px)').matches;
  }

  document.querySelectorAll('[data-phone-action]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      e.preventDefault();
      var phone = el.getAttribute('data-phone-action');
      var phoneDisplay = el.getAttribute('data-phone-display') || phone;
      if (isMobile()) {
        window.location.href = 'tel:' + phone;
      } else {
        showToast('Esta opción solo está disponible desde el móvil. Llámanos al ' + phoneDisplay + '.');
      }
    });
  });
});
